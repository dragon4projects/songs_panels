# TEEA_INT_20261123_006 — COMPOSITION REPORT

All 12 variants were re-authored as shallow physical cutaway rooms rather than horizontal decorated strips. The common shell supplies readable depth independently of furniture. Furniture and stations reinforce rear/mid/front ordering.

Music prioritizes a rear media wall and staggered listening cluster. Cinema separates the main screen from the secondary television/game corner. Artifact uses asymmetrical display depths with negative circulation space rather than a cabinet wall. Workshop separates rear storage, mid work surfaces and front approach/seating.

R2/R3 are authored as one continuous larger room with uneven clusters and circulation; no wide room is produced by mechanically duplicating R1.

The final machine gate is strict and independent of the authoring script: all station bounds/module/spacing/approach/source-footprint checks pass, all 48 final PNG meet the image contract, all yaw sets are distinct, and all strict R2/R3 cross-band depth separations meet the >=0.45 m target.
