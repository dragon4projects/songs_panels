# TEEA_INT_20261123_006 — DELIVERY REPORT

machine_status: READY_FOR_INTEGRATOR_QA
owner_approved: false
production_mutated: false
integration_target: dragon-house-fallout-fresh@1216e2f1a737008e3d9fea0f5d240d54a78a6ea2
variants: 12
production_png: 48
measured_stations: 33
foreground_variants: 12
depth_readability_pass: 12/12
yaw_proof: 12/12 at -0.18 / 0 / +0.18
station_bounds_errors: 0
module_index_errors: 0
spacing_errors: 0
foreign_collision_approach_intersections: 0
station_inside_unrelated_furniture_errors: 0
source_footprint_errors: 0
image_qa: PASS
harvest_qa: PASS
godot_4_7_2_image_load: PASS 48/48
visual_owner_approval: PENDING
