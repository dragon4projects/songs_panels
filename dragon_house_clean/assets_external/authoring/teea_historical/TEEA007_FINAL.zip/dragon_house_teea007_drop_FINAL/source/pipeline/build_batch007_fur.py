import bpy,math,json
from pathlib import Path
ROOT=Path('/home/user/dragonhouse_asset_pipeline');OUT=ROOT/'batch007'/'props';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
mat=bpy.data.materials.new('FurMat_DarkBrown');mat.use_nodes=True;b=mat.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(.12,.055,.028,1);b.inputs['Roughness'].default_value=.95
n=24;top=[];bot=[]
for i in range(n):
 a=2*math.pi*i/n
 wob=1+.10*math.sin(3*a)+.055*math.sin(7*a+0.4)
 x=.72*wob*math.cos(a);y=.38*(1+.08*math.sin(5*a))*math.sin(a)
 top.append((x,y,.018));bot.append((x,y,0))
verts=top+bot;faces=[]
faces.append(tuple(range(n)))
faces.append(tuple(range(2*n-1,n-1,-1)))
for i in range(n):
 j=(i+1)%n;faces.append((i,j,n+j,n+i))
me=bpy.data.meshes.new('FurRestMat');me.from_pydata(verts,[],faces);me.materials.append(mat);ob=bpy.data.objects.new('FurRestMat',me);bpy.context.collection.objects.link(ob)
e=bpy.data.objects.new('REST_ANCHOR',None);bpy.context.collection.objects.link(e);e.location=(0,0,.018)
e['kind']='floor_rest';e['pose_hint']='SLEEP'
bpy.ops.export_scene.gltf(filepath=str(OUT/'dragon_fur_rest_mat.glb'),export_format='GLB',export_materials='EXPORT')
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'dragon_fur_rest_mat.blend'))
meta={'schema':1,'asset_id':'dragon_fur_rest_mat','provenance':'PROJECT_ORIGINAL','dimensions_m':[1.44,.76,.018],'collision':'NONE_SOFT_FLOOR','station_anchor_local':[0,0,.018],'station_kind':'floor_rest','pose_hint':'SLEEP','note':'Low soft floor-rest prop intended near Common hearth; no rigid collision footprint.'}
(OUT/'fur_rest_mat_manifest.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))

