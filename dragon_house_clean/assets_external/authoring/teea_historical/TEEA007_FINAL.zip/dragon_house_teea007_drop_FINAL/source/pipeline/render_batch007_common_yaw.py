import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
manual=float(argv[0]);out=argv[1]
PW=9.6;zoom=13.9
close_bias=max(0.0,min(1.0,(48.0-zoom)/34.0))*0.075
view_yaw=max(-.38,min(.38,manual+close_bias))
height_ratio=.055+(.16-.055)*max(0.0,min(1.0,(zoom-12.0)/36.0))
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=12;s.render.resolution_x=768;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.filepath=out;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
w=bpy.data.worlds.new('World');s.world=w;w.use_nodes=True;w.node_tree.nodes['Background'].inputs['Color'].default_value=(.025,.022,.021,1);w.node_tree.nodes['Background'].inputs['Strength'].default_value=.12
def texmat(name,path):
 img=bpy.data.images.load(str(path),check_existing=False);m=bpy.data.materials.new(name);m.use_nodes=True
 nt=m.node_tree;nt.nodes.clear();outn=nt.nodes.new('ShaderNodeOutputMaterial');mix=nt.nodes.new('ShaderNodeMixShader');tr=nt.nodes.new('ShaderNodeBsdfTransparent');em=nt.nodes.new('ShaderNodeEmission');tx=nt.nodes.new('ShaderNodeTexImage');tx.image=img
 nt.links.new(tx.outputs['Color'],em.inputs['Color']);em.inputs['Strength'].default_value=1;nt.links.new(tx.outputs['Alpha'],mix.inputs[0]);nt.links.new(tr.outputs[0],mix.inputs[1]);nt.links.new(em.outputs[0],mix.inputs[2]);nt.links.new(mix.outputs[0],outn.inputs['Surface']);return m
def plane(name,path,gx,gy,gz,wid,hei):
 verts=[(-wid/2,0,-hei/2),(wid/2,0,-hei/2),(wid/2,0,hei/2),(-wid/2,0,hei/2)]
 me=bpy.data.meshes.new(name+'Mesh');me.from_pydata(verts,[],[(0,1,2,3)]);me.uv_layers.new()
 for i,uv in enumerate([(0,0),(1,0),(1,1),(0,1)]):me.uv_layers.active.data[i].uv=uv
 o=bpy.data.objects.new(name,me);s.collection.objects.link(o);o.location=(gx,-gz,gy);o.data.materials.append(texmat(name+'Mat',path));return o
def flat(name,c):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=.75;return m
def actor(x,z,c):
 m=flat('actor'+str(x)+str(z),c)
 bpy.ops.mesh.primitive_cube_add(location=(x,-z,.85));o=bpy.context.object;o.dimensions=(.38,.08,.95);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.16,location=(x,-z,1.48));bpy.context.object.data.materials.append(m)
d=ROOT/'batch007/common_addendum/R2';h=PW/1.5
for role,z in [('backdrop',-1.79),('back_decor',-1.63),('furniture_back',-1.37)]:plane('Art_'+role,d/(role+'.png'),0,1.5,z,PW,h)
focus=Vector((0,0,1.45));cam_g=Vector((math.sin(view_yaw)*zoom,1.45+zoom*height_ratio,math.cos(view_yaw)*zoom));cam_b=Vector((cam_g.x,-cam_g.z,cam_g.y))
cd=bpy.data.cameras.new('Cam');cam=bpy.data.objects.new('Cam',cd);s.collection.objects.link(cam);s.camera=cam;cd.type='PERSP';cd.angle=math.radians(35);cam.location=cam_b;cam.rotation_euler=(focus-cam.location).to_track_quat('-Z','Y').to_euler()
# measured 005 + 007 station centers
a=json.loads((ROOT/'batch005/generated/TEEA_INT_20261123_005_furniture_anchors_candidate.json').read_text())['room_variants']['common/R2']['stations']
for st in a:actor(float(st['group_local_x']),float(st['cell_local_z']),(.15,.58,.68))
g=json.loads((ROOT/'batch007/generated/TEEA_INT_20261123_007_common_function_addendum.json').read_text())
for nf in g['new_furniture']:
 st=nf['station'];actor(float(st['x']),float(st['z']),(.80,.44,.10))
# exact foreground registration from current room math
reference=Vector((0,1.5,-1.37));target_z=.15
den=reference.z-cam_g.z;k=(target_z-cam_g.z)/den
fg=cam_g+(reference-cam_g)*k
plane('Art_foreground',d/'foreground.png',fg.x,fg.y,target_z,PW*k,h*k)
# QA floor light
fm=flat('floor',(.11,.075,.06));bpy.ops.mesh.primitive_cube_add(location=(0,-.2,-.055));fo=bpy.context.object;fo.dimensions=(PW,3.1,.11);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);fo.data.materials.append(fm)
ld=bpy.data.lights.new('key','AREA');ld.energy=800;ld.size=4;lo=bpy.data.objects.new('key',ld);s.collection.objects.link(lo);lo.location=(0,-4,4);lo.rotation_euler=(Vector((0,0,1))-lo.location).to_track_quat('-Z','Y').to_euler()
Path(out).parent.mkdir(parents=True,exist_ok=True);bpy.ops.render.render(write_still=True)
print('COMMON007_YAW manual',manual,'effective',view_yaw,'zoom',zoom,'fg_k',k,'fg_pos',tuple(fg))

