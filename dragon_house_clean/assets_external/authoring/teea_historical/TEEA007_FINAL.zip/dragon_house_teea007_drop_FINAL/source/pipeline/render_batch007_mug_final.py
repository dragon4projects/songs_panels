import bpy
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline');P=ROOT/'batch007/props';PRE=P/'previews';PRE.mkdir(parents=True,exist_ok=True)
def reset():
 bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=12;s.render.resolution_x=512;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG'
 w=bpy.data.worlds.new('World');s.world=w;w.use_nodes=True;w.node_tree.nodes['Background'].inputs['Color'].default_value=(.025,.025,.028,1);w.node_tree.nodes['Background'].inputs['Strength'].default_value=.18
 return s
def flat(name,c):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=.7;return m
def box(name,loc,size,ma):
 bpy.ops.mesh.primitive_cube_add(location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma)
def setup(target=(0,0,.045),loc=(.19,-.28,.15)):
 s=bpy.context.scene;cd=bpy.data.cameras.new('Cam');cam=bpy.data.objects.new('Cam',cd);s.collection.objects.link(cam);s.camera=cam;cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cd.lens=58
 ld=bpy.data.lights.new('Key','AREA');ld.energy=600;ld.size=2.2;lo=bpy.data.objects.new('Key',ld);s.collection.objects.link(lo);lo.location=(-.7,-1.1,1.6);lo.rotation_euler=(Vector(target)-lo.location).to_track_quat('-Z','Y').to_euler()
def render(n):
 bpy.context.scene.render.filepath=str(PRE/(n+'.png'));bpy.ops.render.render(write_still=True)
for stem in ['dragon_mug_lod0_empty','dragon_mug_lod0_filled','dragon_mug_lod1_empty']:
 reset();bpy.ops.import_scene.gltf(filepath=str(P/(stem+'.glb')));setup();render(stem)
reset();bpy.ops.import_scene.gltf(filepath=str(P/'dragon_mug_lod0_filled.glb'));table=flat('table',(.18,.10,.06));hand=flat('hand',(.12,.55,.65));box('TABLE',(0,0,-.035),(.70,.45,.07),table);box('QA_HAND_ENVELOPE',(.155,-.035,.055),(.18,.09,.04),hand);setup((0,0,.04),(.36,-.50,.28));render('dragon_mug_tabletop_access')
print('MUG_PREVIEWS_FINAL')

