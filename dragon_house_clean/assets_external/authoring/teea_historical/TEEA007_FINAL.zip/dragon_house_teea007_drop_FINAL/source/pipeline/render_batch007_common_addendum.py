import bpy,bmesh,math,json,sys
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
BASE=ROOT/'batch005/final/common/R2'
OUT=ROOT/'batch007/common_addendum/R2';OUT.mkdir(parents=True,exist_ok=True)
PW=9.6
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=14;s.render.resolution_x=768;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='8';s.render.film_transparent=True
try:s.view_settings.look='AgX - Medium High Contrast'
except:pass
def bbox(objs):
 pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box]
 return Vector((min(p.x for p in pts),min(p.y for p in pts),min(p.z for p in pts))),Vector((max(p.x for p in pts),max(p.y for p in pts),max(p.z for p in pts)))
def source_gltf(aid):
 d=json.loads(next((ROOT/'source_assets'/aid).glob('*/SOURCE.json')).read_text());return Path(d.get('gltf_normalized') or d['gltf'])
def import_asset(aid,x,z,scale,id):
 before=set(s.objects);bpy.ops.import_scene.gltf(filepath=str(source_gltf(aid)));new=[o for o in s.objects if o not in before];meshes=[o for o in new if o.type=='MESH'];roots=[o for o in new if o.parent is None]
 piv=bpy.data.objects.new('PIV_'+id,None);s.collection.objects.link(piv)
 for o in roots:o.parent=piv
 piv.scale=(scale,scale,scale);bpy.context.view_layer.update();mn,mx=bbox(meshes)
 piv.location.x+=-(mn.x+mx.x)/2+x;piv.location.y+=-(mn.y+mx.y)/2+(-z);piv.location.z+=-mn.z;bpy.context.view_layer.update();return piv,meshes,bbox(meshes)
def area():
 d=bpy.data.lights.new('area','AREA');d.energy=250;d.size=3.2;d.color=(1,.7,.5);o=bpy.data.objects.new('area',d);s.collection.objects.link(o);o.location=(2,-2.8,2.45);o.rotation_euler=(Vector((2,.5,1.15))-o.location).to_track_quat('-Z','Y').to_euler()
def cam():
 cd=bpy.data.cameras.new('WIDTH_CAMERA');o=bpy.data.objects.new('WIDTH_CAMERA',cd);s.collection.objects.link(o);s.camera=o;o.location=(0,-12,1.5);o.rotation_euler=(Vector((0,0,1.5))-o.location).to_track_quat('-Z','Y').to_euler();cd.type='ORTHO';cd.ortho_scale=PW
 w=bpy.data.worlds.new('World');s.world=w;w.use_nodes=True;w.node_tree.nodes['Background'].inputs['Color'].default_value=(.018,.016,.015,1);w.node_tree.nodes['Background'].inputs['Strength'].default_value=.16
def render(path):s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
# full additions
piv,meshes,(mn,mx)=import_asset('Sofa_01',2.0,-.14610654,.90,'sofa')
bpy.ops.import_scene.gltf(filepath=str(ROOT/'batch007/props/dragon_fur_rest_mat.glb'))
newfur=[o for o in s.objects if o.name.startswith('FurRestMat') or o.name=='FurRestMat']
for o in newfur:o.location=(0,-.32,0)
cam();area();render(OUT/'additions_half.png')
# copy full scene sofa geometry world transformed then crop front of seat
# hide fur in foreground
for o in newfur:o.hide_render=True
seat_y=0.08794529444486561
clip_y=seat_y-.012
for src in list(meshes):
 me=src.data.copy()
 for v in me.vertices:v.co=src.matrix_world@v.co
 ob=bpy.data.objects.new('FG_'+src.name,me);s.collection.objects.link(ob)
 me.materials.clear()
 for m in src.data.materials:me.materials.append(m)
 bm=bmesh.new();bm.from_mesh(me);geom=list(bm.verts)+list(bm.edges)+list(bm.faces)
 bmesh.ops.bisect_plane(bm,geom=geom,dist=.0001,plane_co=Vector((0,clip_y,0)),plane_no=Vector((0,1,0)),clear_outer=True,clear_inner=False)
 bm.to_mesh(me);bm.free()
# hide original sofa
piv.hide_render=True
render(OUT/'sofa_foreground_half.png')
print('front_z',-mn.y,'clip_godot_z',-clip_y)

