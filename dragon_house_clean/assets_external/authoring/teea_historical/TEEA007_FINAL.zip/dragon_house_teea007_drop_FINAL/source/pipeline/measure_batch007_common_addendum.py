import bpy,json,math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
m=json.loads((ROOT/'batch005/generated/TEEA_INT_20261123_005_anchor_measurements.json').read_text())['common/R2']
a=json.loads((ROOT/'batch005/generated/TEEA_INT_20261123_005_furniture_anchors_candidate.json').read_text())['room_variants']['common/R2']
def bbox(objs):
 pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box]
 return Vector((min(p.x for p in pts),min(p.y for p in pts),min(p.z for p in pts))),Vector((max(p.x for p in pts),max(p.y for p in pts),max(p.z for p in pts)))
def load_asset(aid,x,z,scale):
 d=json.loads(next((ROOT/'source_assets'/aid).glob('*/SOURCE.json')).read_text());gp=d.get('gltf_normalized') or d['gltf']
 bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;bpy.ops.import_scene.gltf(filepath=gp)
 meshes=[o for o in s.objects if o.type=='MESH'];roots=[o for o in s.objects if o.parent is None]
 piv=bpy.data.objects.new('PIV',None);s.collection.objects.link(piv)
 for o in roots:o.parent=piv
 piv.scale=(scale,scale,scale);bpy.context.view_layer.update();mn,mx=bbox(meshes)
 piv.location.x+=-(mn.x+mx.x)/2+x;piv.location.y+=-(mn.y+mx.y)/2-z;piv.location.z+=-mn.z;bpy.context.view_layer.update();mn,mx=bbox(meshes)
 return s,meshes,mn,mx
def fp(mn,mx):return [[mn.x,-mx.y],[mx.x,-mx.y],[mx.x,-mn.y],[mn.x,-mn.y]]
def bounds(poly):
 xs=[p[0] for p in poly];zs=[p[1] for p in poly];return min(xs),max(xs),min(zs),max(zs)
def overlap(a,b,margin=0):
 ax0,ax1,az0,az1=bounds(a);bx0,bx1,bz0,bz1=bounds(b)
 return max(ax0,bx0)+margin<min(ax1,bx1) and max(az0,bz0)+margin<min(az1,bz1)
def raycast_seat(s,mn,mx):
 dg=bpy.context.evaluated_depsgraph_get();pts=[];hist={}
 for ix in range(80):
  x=mn.x+(mx.x-mn.x)*(ix+.5)/80
  for iy in range(60):
   y=mn.y+(mx.y-mn.y)*(iy+.5)/60
   hit,loc,norm,face,obj,mat=s.ray_cast(dg,Vector((x,y,mx.z+.5)),Vector((0,0,-1)),distance=(mx.z-mn.z)+1.5)
   if hit and .15<=loc.z<=min(.95,mx.z-.02) and norm.z>.35:
    pts.append((x,y,loc.z));k=round(loc.z/.04)*.04;hist[k]=hist.get(k,0)+1
 peak=max(hist.items(),key=lambda x:x[1])[0];sel=[p for p in pts if abs(p[2]-peak)<.07]
 return {'x':sum(p[0] for p in sel)/len(sel),'z':-(sum(p[1] for p in sel)/len(sel)),'height':sum(p[2] for p in sel)/len(sel),'count':len(sel)}
s,meshes,mn,mx=load_asset('Sofa_01',2.0,-.14610654,.90);sfp=fp(mn,mx);seat=raycast_seat(s,mn,mx)
existing={}
for oid,d in m.items():
 if oid in [x['furniture_id'] for x in a['stations']] or oid=='common_r2_side_table_left' or oid=='common_r2_shared_table':
  existing[oid]=d['collision_footprint_group']
collisions=[oid for oid,p in existing.items() if overlap(sfp,p)]
# Approach from aisle .95 to sofa seat
approach_hits=[]
for oid,p in existing.items():
 x=seat['x'];lo=min(.95,seat['z']);hi=max(.95,seat['z']);x0,x1,z0,z1=bounds(p)
 if x0+.035<x<x1-.035 and max(lo,z0)<min(hi,z1):approach_hits.append(oid)
# Existing station approaches against new sofa
blocked=[]
x0,x1,z0,z1=bounds(sfp)
for st in a['stations']:
 x=float(st['group_local_x']);lo=min(float(st['approach_local_z']),float(st['cell_local_z']));hi=max(float(st['approach_local_z']),float(st['cell_local_z']))
 if x0+.035<x<x1-.035 and max(lo,z0)<min(hi,z1):blocked.append(st['id'])
fur={'x':0.0,'z':0.32,'width':1.44,'depth':.76,'station':[0.0,.32]}
# mug placements on shared table top
mugs=[{'id':'common_r2_mug_slot_a','x':-.48,'y':.84,'z':-1.22},{'id':'common_r2_mug_slot_b','x':.48,'y':.84,'z':-1.22}]
rep={'schema':1,'batch_id':'TEEA_INT_20261123_007','base':'TEEA_INT_20261123_005 common/R2',
 'sofa':{'asset':'Sofa_01','transform':{'x':2.0,'z':-.14610654,'scale':.9},'bbox':{'min':[mn.x,-mx.y,mn.z],'max':[mx.x,-mn.y,mx.z]},'footprint':sfp,'seat':seat,'foreign_collision_overlaps':collisions,'approach_hits':approach_hits,'blocks_existing_station_approaches':blocked},
 'fur_rest':fur,'mug_slots':mugs}
# spacing
sts=[(x['id'],x['group_local_x'],x['cell_local_z']) for x in a['stations']]+[('common_r2_sofa_rest',seat['x'],seat['z']),('common_r2_fur_rest',0,.32)]
rep['station_pair_min_distance']=min((math.hypot(float(x1)-float(x2),float(z1)-float(z2)),id1,id2) for i,(id1,x1,z1) in enumerate(sts) for id2,x2,z2 in sts[i+1:])
rep['pass']=not collisions and not approach_hits and not blocked and rep['station_pair_min_distance'][0]>=.65
OUT=ROOT/'batch007/generated';OUT.mkdir(parents=True,exist_ok=True)
(OUT/'TEEA_INT_20261123_007_common_addendum_geometry.json').write_text(json.dumps(rep,indent=2))
print(json.dumps(rep,indent=2))

