import bpy,json,math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
LAY=json.loads((ROOT/'batch007'/'layout.json').read_text())
OUT=ROOT/'batch007'/'generated';OUT.mkdir(parents=True,exist_ok=True)

def reset(): bpy.ops.wm.read_factory_settings(use_empty=True)
def bbox(objs):
    pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box]
    return Vector((min(p.x for p in pts),min(p.y for p in pts),min(p.z for p in pts))),Vector((max(p.x for p in pts),max(p.y for p in pts),max(p.z for p in pts)))
def source_gltf(aid):
    sj=list((ROOT/'source_assets'/aid).glob('*/SOURCE.json'))[0]
    d=json.loads(sj.read_text())
    # use normalized repaired path when present
    g=d.get('gltf_normalized') or d.get('gltf')
    return Path(g),d
def load_asset(o):
    reset();gp,src=source_gltf(o['asset'])
    bpy.ops.import_scene.gltf(filepath=str(gp))
    meshes=[x for x in bpy.context.scene.objects if x.type=='MESH'];roots=[x for x in bpy.context.scene.objects if x.parent is None]
    piv=bpy.data.objects.new('PIV',None);bpy.context.scene.collection.objects.link(piv)
    for x in roots:x.parent=piv
    sc=float(o.get('scale',1));piv.scale=(sc,sc,sc);piv.rotation_euler[2]=math.radians(float(o.get('rot',0)))
    bpy.context.view_layer.update();mn,mx=bbox(meshes)
    piv.location.x+=-(mn.x+mx.x)/2+float(o['x'])
    piv.location.y+=-(mn.y+mx.y)/2+(-float(o['z']))
    piv.location.z+=-mn.z+float(o.get('height',0))
    bpy.context.view_layer.update();mn,mx=bbox(meshes)
    return bpy.context.scene,meshes,mn,mx,src
def fp(mn,mx): return [[mn.x,-mx.y],[mx.x,-mx.y],[mx.x,-mn.y],[mn.x,-mn.y]]
def bounds(poly):
    xs=[p[0] for p in poly];zs=[p[1] for p in poly];return min(xs),max(xs),min(zs),max(zs)
def rect_circle_intersects(poly,cx,cz,r):
    xmin,xmax,zmin,zmax=bounds(poly)
    qx=min(max(cx,xmin),xmax);qz=min(max(cz,zmin),zmax)
    return (qx-cx)**2+(qz-cz)**2 < r*r
def rect_rect_intersects(a,b,margin=0):
    ax0,ax1,az0,az1=bounds(a);bx0,bx1,bz0,bz1=bounds(b)
    return max(ax0,bx0)+margin<min(ax1,bx1) and max(az0,bz0)+margin<min(az1,bz1)
def proc_fp(p):
    x=float(p['x']);z=float(p['z']);w=float(p['width']);d=float(p['depth'])
    return [[x-w/2,z-d/2],[x+w/2,z-d/2],[x+w/2,z+d/2],[x-w/2,z+d/2]]
def raycast_seat(s,mn,mx):
    dg=bpy.context.evaluated_depsgraph_get();pts=[];hist={}
    for ix in range(72):
        x=mn.x+(mx.x-mn.x)*(ix+.5)/72
        for iy in range(56):
            y=mn.y+(mx.y-mn.y)*(iy+.5)/56
            hit,loc,norm,face,obj,mat=s.ray_cast(dg,Vector((x,y,mx.z+.5)),Vector((0,0,-1)),distance=(mx.z-mn.z)+1.5)
            if hit and .15<=loc.z<=min(1.05,mx.z-.02) and norm.z>=.35:
                pts.append((x,y,loc.z));k=round(loc.z/.04)*.04;hist[k]=hist.get(k,0)+1
    if not hist:return None
    peak=max(hist.items(),key=lambda kv:kv[1])[0];sel=[p for p in pts if abs(p[2]-peak)<=.07]
    return {'x':sum(p[0] for p in sel)/len(sel),'godot_z':-(sum(p[1] for p in sel)/len(sel)),'height':sum(p[2] for p in sel)/len(sel),'count':len(sel)}

report={'schema':1,'batch_id':'TEEA_INT_20261123_007','rooms':{},'errors':[]}
station_doc={'schema':1,'batch_id':'TEEA_INT_20261123_007','approved':False,'room_candidates':{}}
for key,R in LAY['rooms'].items():
    room={'guest_id':R['guest_id'],'display_name':R['display_name'],'access':R['access'],'sizing_contract':R['sizing_contract'],'objects':{},'collision_footprints':{},'runtime_stations':[],'species_conditional_hooks':[],'qa':{}}
    coll={}
    seat_data={}
    for o in R.get('objects',[]):
        s,meshes,mn,mx,src=load_asset(o);poly=fp(mn,mx)
        room['objects'][o['id']]={'asset':o['asset'],'bbox_godot':{'x_min':mn.x,'x_max':mx.x,'z_back':-mx.y,'z_front':-mn.y,'height_min':mn.z,'height_max':mx.z},'footprint':poly,'source_page':src.get('source_page'),'license':src.get('license')}
        if o.get('collision'):coll[o['id']]=poly;room['collision_footprints'][o['id']]=poly
        if o.get('interaction') in ('SEAT_REST','SEAT_READ','OPTIONAL_REST','OPTIONAL_PERCH'):
            seat_data[o['id']]=raycast_seat(s,mn,mx)
    for p in R.get('procedural',[]):
        if 'width' in p and 'depth' in p:
            poly=proc_fp(p)
            room['objects'][p['id']]={'procedural':True,'type':p['type'],'footprint':poly,'height_max':p.get('height')}
            if p.get('collision'):coll[p['id']]=poly;room['collision_footprints'][p['id']]=poly
    # explicit provisional stations for Centaur/Vampire talk
    for s0 in R.get('provisional_stations',[]):
        sid=s0['id'];furniture_id=''
        if sid=='centaur_table_use':furniture_id='centaur_table'
        elif sid=='centaur_rest':furniture_id='centaur_rest_platform'
        elif sid=='centaur_talk':furniture_id='ROOM_FLOOR'
        elif sid=='vampire_talk':furniture_id='ROOM_FLOOR'
        st={**s0,'furniture_id':furniture_id,'approach_local_z':.95,'occupancy_capacity':1,'provisional_due_to_unbound_sprite_scale':True}
        room['runtime_stations'].append(st)
    if key=='guest_vampire/R1':
        if seat_data.get('vampire_daybed'):
            sd=seat_data['vampire_daybed'];room['runtime_stations'].append({'id':'vampire_daybed_rest','furniture_id':'vampire_daybed','x':round(sd['x'],5),'z':round(sd['godot_z'],5),'seat_height_m':round(sd['height'],5),'kind':'seat','pose_hint':'RELAXED_SIT','activity':'rest','approach_local_z':.95,'occupancy_capacity':1,'provisional_due_to_unbound_sprite_scale':True})
        if seat_data.get('vampire_chair'):
            sd=seat_data['vampire_chair'];room['runtime_stations'].append({'id':'vampire_read','furniture_id':'vampire_chair','x':round(sd['x'],5),'z':round(sd['godot_z'],5),'seat_height_m':round(sd['height'],5),'kind':'seat','pose_hint':'READ','activity':'reading','approach_local_z':.95,'occupancy_capacity':1,'provisional_due_to_unbound_sprite_scale':True})
        # personal item use at nightstand front
        poly=coll['vampire_nightstand'];x0,x1,z0,z1=bounds(poly)
        room['runtime_stations'].append({'id':'vampire_personal_item','furniture_id':'vampire_nightstand','x':round((x0+x1)/2,5),'z':round(z1+.30,5),'kind':'standing','pose_hint':'USE','activity':'personal_item','approach_local_z':.95,'occupancy_capacity':1,'provisional_due_to_unbound_sprite_scale':True})
    if key=='guest_miu/R1':
        # Conditional hooks only; no humanoid/quadruped binding is asserted.
        for oid,kind,activity in [('miu_perch','perch','perch_or_sit'),('miu_ottoman','rest_surface','rest_or_sit'),('miu_bowl','feed_drink','drink_or_feed'),('miu_low_pad','floor_rest','rest')]:
            if oid in room['objects']:
                ob=room['objects'][oid]
                poly=ob['footprint'];x0,x1,z0,z1=bounds(poly)
                hook={'id':oid+'_hook','source_furniture_id':oid,'x':round((x0+x1)/2,5),'z':round((z0+z1)/2,5),'kind':kind,'activity':activity,'runtime_station':False,'requires_integrator_form_and_scale_binding':True}
                if seat_data.get(oid): hook['surface_height_m']=round(seat_data[oid]['height'],5)
                room['species_conditional_hooks'].append(hook)
    # geometry QA
    errs=[]
    # room bounds and station-to-foreign-collision approach tests
    for st in room['runtime_stations']:
        if abs(float(st['x']))>2.25 or not (-1.9<=float(st['z'])<=1.0): errs.append('station_out_of_room:'+st['id'])
        za=float(st['approach_local_z']);zb=float(st['z']);gx=float(st['x'])
        lo,hi=min(za,zb),max(za,zb)
        for oid,poly in coll.items():
            if oid==st['furniture_id']:continue
            x0,x1,z0,z1=bounds(poly)
            if x0+.035<gx<x1-.035 and max(lo,z0)<min(hi,z1): errs.append('approach_cross:'+st['id']+':'+oid)
    # station spacing
    sts=room['runtime_stations']
    for i,a in enumerate(sts):
        for b in sts[i+1:]:
            d=math.hypot(float(a['x'])-float(b['x']),float(a['z'])-float(b['z']))
            if d<.55: errs.append('station_spacing:'+a['id']+':'+b['id']+f':{d:.3f}')
    # centaur turning and door clear
    if key=='guest_centaur/R1':
        cx,cz=R['sizing_contract']['turning_center'];rad=R['sizing_contract']['turning_clear_diameter_m']/2
        hits=[oid for oid,poly in coll.items() if rect_circle_intersects(poly,cx,cz,rad)]
        room['qa']['turning_circle']={'center':[cx,cz],'radius_m':rad,'foreign_collisions':hits,'pass':not hits}
        if hits:errs+=['centaur_turning_collision:'+x for x in hits]
    for p in R.get('procedural',[]):
        if p.get('type')=='clearance':
            dpoly=proc_fp(p);hits=[oid for oid,poly in coll.items() if rect_rect_intersects(dpoly,poly)]
            room['qa']['door_clearance']={'id':p['id'],'footprint':dpoly,'foreign_collisions':hits,'pass':not hits}
            if hits:errs+=['door_clearance_collision:'+x for x in hits]
    room['qa']['errors']=errs;room['qa']['geometry_pass']=not errs
    report['rooms'][key]=room
    station_doc['room_candidates'][key]={'runtime_stations':room['runtime_stations'],'species_conditional_hooks':room['species_conditional_hooks'],'access':R['access'],'sizing_contract':R['sizing_contract']}
    report['errors']+= [key+':'+e for e in errs]
report['machine_geometry_pass']=not report['errors']
(OUT/'TEEA_INT_20261123_007_guest_geometry_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
(OUT/'TEEA_INT_20261123_007_guest_station_candidate.json').write_text(json.dumps(station_doc,indent=2,ensure_ascii=False))
print(json.dumps({'machine_geometry_pass':report['machine_geometry_pass'],'errors':report['errors'],'station_counts':{k:len(v['runtime_stations']) for k,v in report['rooms'].items()},'hook_counts':{k:len(v['species_conditional_hooks']) for k,v in report['rooms'].items()}},indent=2,ensure_ascii=False))

