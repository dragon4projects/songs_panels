extends SceneTree
var errs:Array[String]=[]
var png_rows=[]
var glb_rows=[]
func walk_names(n:Node, out:Array[String]):
 out.append(n.name)
 for c in n.get_children(): walk_names(c,out)
func _initialize():
 var rootp='/home/user/dragonhouse_asset_pipeline/batch007'
 var pngs=[
  rootp+'/final/guest_centaur/R1/backdrop.png', rootp+'/final/guest_centaur/R1/back_decor.png', rootp+'/final/guest_centaur/R1/furniture_back.png',
  rootp+'/final/guest_vampire/R1/backdrop.png', rootp+'/final/guest_vampire/R1/back_decor.png', rootp+'/final/guest_vampire/R1/furniture_back.png',
  rootp+'/final/guest_miu/R1/backdrop.png', rootp+'/final/guest_miu/R1/back_decor.png', rootp+'/final/guest_miu/R1/furniture_back.png',
  rootp+'/common_addendum/R2/backdrop.png', rootp+'/common_addendum/R2/back_decor.png', rootp+'/common_addendum/R2/furniture_back.png', rootp+'/common_addendum/R2/foreground.png'
 ]
 for p in pngs:
  var im=Image.new(); var e=im.load(p)
  var row={'path':p,'error':e}
  if e!=OK: errs.append('png_load:'+p)
  else:
   row['size']=[im.get_width(),im.get_height()]; row['format']=im.get_format()
   if im.get_width()!=1536 or im.get_height()!=1024: errs.append('png_size:'+p)
   if im.get_format()!=Image.FORMAT_RGBA8: errs.append('png_format:'+p+':'+str(im.get_format()))
   var tex=ImageTexture.create_from_image(im)
   if tex==null or tex.get_width()!=1536: errs.append('png_texture:'+p)
  png_rows.append(row)
 var glbs=['dragon_mug_lod0_empty.glb','dragon_mug_lod0_filled.glb','dragon_mug_lod1_empty.glb','media_holder_book.glb','media_holder_film_poster.glb','media_holder_audio.glb','media_holder_artifact.glb','media_holder_film_screen.glb','dragon_fur_rest_mat.glb']
 var required=['MEDIA_SURFACE','LABEL_ANCHOR','HOVER_HIT','FULLSCREEN_TRIGGER_ANCHOR','PLACEMENT_ANCHOR']
 for fn in glbs:
  var p=rootp+'/props/'+fn
  var doc=GLTFDocument.new(); var st=GLTFState.new(); var e=doc.append_from_file(p,st)
  var row={'path':p,'error':e}
  if e!=OK: errs.append('glb_parse:'+fn+':'+str(e))
  else:
   var scene=doc.generate_scene(st)
   if scene==null: errs.append('glb_scene:'+fn)
   else:
    var names:Array[String]=[]; walk_names(scene,names); row['nodes']=names
    if fn.begins_with('media_holder_'):
     for req in required:
      if not names.has(req): errs.append('holder_node:'+fn+':'+req)
    if fn.begins_with('dragon_mug_'):
     if not names.has('PLACEMENT_ANCHOR') or not names.has('PICKUP_ANCHOR') or not names.has('RIM_CENTER'): errs.append('mug_anchor:'+fn)
    scene.free()
  glb_rows.append(row)
 print('TEEA007_GODOT_QA ',JSON.stringify({'pass':errs.is_empty(),'errors':errs,'png_count':png_rows.size(),'glb_count':glb_rows.size(),'pngs':png_rows,'glbs':glb_rows}))
 quit(0 if errs.is_empty() else 2)
