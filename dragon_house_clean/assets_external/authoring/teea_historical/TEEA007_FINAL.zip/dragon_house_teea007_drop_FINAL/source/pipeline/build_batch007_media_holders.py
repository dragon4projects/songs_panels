import bpy, json, math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
OUT=ROOT/'batch007'/'props';OUT.mkdir(parents=True,exist_ok=True)

def reset(): bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(name,c,metal=0,rough=.65):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough;return m
def box(name,loc,size,ma=None):
 bpy.ops.mesh.primitive_cube_add(location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if ma:o.data.materials.append(ma)
 return o
def empty(name,loc):
 e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.location=loc;return e
def frame(kind,outer_w,outer_h,inner_w,inner_h,depth=.04):
 reset();wood=mat('Frame_DarkWood',(.12,.075,.05),0,.58);surf=mat('MediaSurface_Neutral',(.035,.035,.038),0,.82);metal=mat('Backplate_Dark',(.025,.025,.028),.2,.75)
 bar=(outer_w-inner_w)/2;z=outer_h/2
 box('FRAME_TOP',(0,0,z-bar/2),(outer_w,depth,bar),wood);box('FRAME_BOTTOM',(0,0,-z+bar/2),(outer_w,depth,bar),wood)
 box('FRAME_LEFT',(-outer_w/2+bar/2,0,0),(bar,depth,inner_h),wood);box('FRAME_RIGHT',((outer_w/2-bar/2),0,0),(bar,depth,inner_h),wood)
 box('BACKPLATE',(0,depth*.25,0),(inner_w+.01,depth*.35,inner_h+.01),metal)
 # media surface faces camera at y negative
 ms=box('MEDIA_SURFACE',(0,-depth*.55,0),(inner_w,.004,inner_h),surf)
 empty('LABEL_ANCHOR',(0,-depth*.8,-outer_h/2-.10))
 empty('FULLSCREEN_TRIGGER_ANCHOR',(0,-depth*.9,0))
 # hit area represented by empty with custom props
 h=empty('HOVER_HIT',(0,-depth*.85,0));h['bbox_m']=[inner_w,inner_h,.05]
 empty('PLACEMENT_ANCHOR',(0,0,-outer_h/2))
 meta={'kind':kind,'outer_size_m':[outer_w,outer_h,depth],'media_surface_size_m':[inner_w,inner_h],'media_surface_bbox_local':[-inner_w/2,-inner_h/2,inner_w/2,inner_h/2],
       'hover_hit_size_m':[inner_w,inner_h,.05],'label_anchor_local':[0,-depth*.8,-outer_h/2-.10],'fullscreen_trigger_anchor_local':[0,-depth*.9,0]}
 glb=OUT/f'media_holder_{kind}.glb';blend=OUT/f'media_holder_{kind}.blend'
 bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',export_materials='EXPORT');bpy.ops.wm.save_as_mainfile(filepath=str(blend))
 return meta
def screen():
 reset();frame_mat=mat('ScreenFrame',(0.045,.038,.034),.15,.55);surf=mat('ScreenSurface',(0.08,.085,.09),0,.78)
 ow,oh,iw,ih,d=2.65,1.60,2.40,1.35,.07;bar=(ow-iw)/2
 box('FRAME_TOP',(0,0,oh/2-bar/2),(ow,d,bar),frame_mat);box('FRAME_BOTTOM',(0,0,-oh/2+bar/2),(ow,d,bar),frame_mat)
 box('FRAME_LEFT',(-ow/2+bar/2,0,0),(bar,d,ih),frame_mat);box('FRAME_RIGHT',(ow/2-bar/2,0,0),(bar,d,ih),frame_mat)
 box('MEDIA_SURFACE',(0,-d*.55,0),(iw,.005,ih),surf)
 empty('LABEL_ANCHOR',(0,-d*.8,-oh/2-.12));empty('FULLSCREEN_TRIGGER_ANCHOR',(0,-d*.9,0));h=empty('HOVER_HIT',(0,-d,0));h['bbox_m']=[iw,ih,.08];empty('PLACEMENT_ANCHOR',(0,0,-oh/2))
 meta={'kind':'film_screen','outer_size_m':[ow,oh,d],'media_surface_size_m':[iw,ih],'media_surface_bbox_local':[-iw/2,-ih/2,iw/2,ih/2],'hover_hit_size_m':[iw,ih,.08],'label_anchor_local':[0,-d*.8,-oh/2-.12],'fullscreen_trigger_anchor_local':[0,-d*.9,0]}
 glb=OUT/'media_holder_film_screen.glb';blend=OUT/'media_holder_film_screen.blend'
 bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',export_materials='EXPORT');bpy.ops.wm.save_as_mainfile(filepath=str(blend))
 return meta
manifest={'schema':1,'provenance':'PROJECT_ORIGINAL','holders':{}}
manifest['holders']['book']=frame('book',.38,.54,.29,.43,.038)
manifest['holders']['film_poster']=frame('film_poster',.72,1.02,.60,.90,.045)
manifest['holders']['audio']=frame('audio',.56,.56,.45,.45,.038)
manifest['holders']['artifact']=frame('artifact',.42,.26,.32,.16,.034)
manifest['holders']['film_screen']=screen()
for k in manifest['holders']:
 manifest['holders'][k]['glb']=str(OUT/f'media_holder_{k}.glb');manifest['holders'][k]['blend']=str(OUT/f'media_holder_{k}.blend')
(OUT/'media_holder_manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))

