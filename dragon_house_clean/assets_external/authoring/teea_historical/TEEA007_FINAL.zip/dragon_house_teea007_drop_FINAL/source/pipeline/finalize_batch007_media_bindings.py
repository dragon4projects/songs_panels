import json, math
from pathlib import Path

ROOT=Path('/home/user/dragonhouse_asset_pipeline')
P007=ROOT/'batch007/generated/TEEA_INT_20261123_007_media_hooks.json'
P006_LAYOUT=ROOT/'batch006/layout.json'
P006_ANCH=ROOT/'batch006/generated/TEEA_INT_20261123_006_furniture_anchors_candidate.json'
P006_MEAS=ROOT/'batch006/generated/TEEA_INT_20261123_006_anchor_measurements.json'
HOLDERS=ROOT/'batch007/props/media_holder_manifest.json'
OUT=ROOT/'batch007/generated'

hooks=json.loads(P007.read_text())
layout=json.loads(P006_LAYOUT.read_text())
anchors=json.loads(P006_ANCH.read_text())
meas=json.loads(P006_MEAS.read_text())
holders=json.loads(HOLDERS.read_text())['holders']

# Exact final TEEA006 placement references.
# position = [group_local_x, vertical_y, godot_local_z]
B={
# MUSIC
'music.r1.audio.01':([-1.55,1.28,-1.55],'music_r1_media_shelf',None,'pointer'),
'music.r1.audio.02':([ 1.20,1.28,-1.55],'music_r1_portable',None,'pointer'),
'music.r2.audio.01':([-3.72,1.28,-1.55],'music_r2_shelf_left',None,'pointer'),
'music.r2.audio.02':([ 0.70,1.28,-1.55],'music_r2_ukulele',None,'pointer'),
'music.r2.audio.03':([ 3.60,1.28,-1.55],'music_r2_audio_right',None,'pointer'),
'music.r3.audio.01':([-6.15,1.28,-1.55],'music_r3_shelf_left',None,'pointer'),
'music.r3.audio.02':([-2.20,1.28,-1.55],'TEEA006_music_rear_audio_zone',None,'pointer'),
'music.r3.audio.03':([ 1.10,1.28,-1.55],'music_r3_console',None,'pointer'),
'music.r3.audio.04':([ 5.72,1.28,-1.55],'music_r3_audio_right',None,'pointer'),

# CINEMA. screen x matches exact TEEA006 screen geometry; poster slots stay outside screen/gameplay furniture.
'cinema.r1.film.screen':([-0.15,1.58,-1.55],'TEEA006_cinema_screen',None,'pointer'),
'cinema.r1.film.poster.01':([-2.00,2.25,-1.55],'TEEA006_left_rear_wall_zone',None,'pointer'),
'cinema.r1.film.poster.02':([ 1.92,2.35,-1.55],'TEEA006_upper_game_nook_wall',None,'pointer'),
'cinema.r2.film.screen':([-0.75,1.58,-1.55],'TEEA006_cinema_screen',None,'pointer'),
'cinema.r2.film.poster.01':([-3.65,1.72,-1.55],'cinema_r2_frame',None,'pointer'),
'cinema.r2.film.poster.02':([ 2.00,2.25,-1.55],'TEEA006_right_of_screen_wall_zone',None,'pointer'),
'cinema.r3.film.screen':([-1.35,1.58,-1.55],'TEEA006_cinema_screen',None,'pointer'),
'cinema.r3.film.poster.01':([-6.12,1.70,-1.55],'cinema_r3_frame_l',None,'pointer'),
'cinema.r3.film.poster.02':([ 3.10,2.25,-1.55],'TEEA006_between_screen_and_game_nook',None,'pointer'),

# ARTIFACT: labels sit on/in front of final 006 display geometry; view stations already pass 006 approach/collision QA.
'artifact.r1.label.01':([-0.30,.90,-.270],'artifact_r1_pedestal','artifact_r1_pedestal_view','station'),
'artifact.r1.label.02':([ 1.30,.95,-1.105],'artifact_r1_cabinet','artifact_r1_cabinet_view','station'),
'artifact.r2.label.01':([-1.45,.92,-.405],'artifact_r2_pedestal_mid','artifact_r2_pedestal_mid_view','station'),
'artifact.r2.label.02':([ 1.35,.92, .350],'artifact_r2_pedestal_front','artifact_r2_pedestal_front_view','station'),
'artifact.r2.label.03':([ 3.25,.95,-1.175],'artifact_r2_cabinet','artifact_r2_cabinet_view','station'),
'artifact.r3.label.01':([-2.85,.94,-.380],'artifact_r3_pedestal_mid','artifact_r3_pedestal_mid_view','station'),
'artifact.r3.label.02':([ 0.35,.95,-1.160],'artifact_r3_cabinet_mid','artifact_r3_cabinet_mid_view','station'),
'artifact.r3.label.03':([ 3.15,.94, .370],'artifact_r3_pedestal_front','artifact_r3_pedestal_front_view','station'),
'artifact.r3.label.04':([ 5.25,.58, .300],'artifact_r3_chest',None,'pointer'),
}

# Layout collision polygons for cross-check of station-bound holder placement.
def rb(poly):
    xs=[p[0] for p in poly]; zs=[p[1] for p in poly]
    return min(xs),max(xs),min(zs),max(zs)

def overlap(a,b):
    return max(a[0],b[0]) < min(a[1],b[1]) and max(a[2],b[2]) < min(a[3],b[3])

station_index={}
for key,rv in anchors['room_variants'].items():
    for st in rv['stations']:
        station_index[(key,st['id'])]=st

errors=[]
bound=[]
updated=0

for s in hooks['surfaces']:
    sid=s['surface_id']
    if sid not in B:
        continue
    pos,src,station_id,mode=B[sid]
    room=s['room_id']; var=s['variant']; key=f'{room}/{var}'
    w=int(var[1]); pw=4.8*w
    hkind={'audio':'audio','film':'film_screen' if '.screen' in sid else 'film_poster','artifact':'artifact'}[s['media_kind']]
    hm=holders[hkind]
    outer=hm['outer_size_m']; media=hm['media_surface_size_m']; hit=hm['hover_hit_size_m']
    x,y,z=map(float,pos)

    # room envelope; allow shallow rear holder thickness but never outside cutaway.
    if x-outer[0]/2 < -pw/2+.02 or x+outer[0]/2 > pw/2-.02:
        errors.append(f'{sid}:x_room_bounds')
    if y-outer[1]/2 < .02 or y+outer[1]/2 > 3.08:
        errors.append(f'{sid}:y_room_bounds')
    if z < -2.00 or z > .90:
        errors.append(f'{sid}:z_room_bounds')

    s['transform']['position_m']=[round(x,5),round(y,5),round(z,5)]
    s['transform']['rotation_deg']=[0,0,0]; s['transform']['scale']=[1,1,1]
    s['bounding_box_m']={'center':[round(x,5),round(y,5),round(z,5)],
                         'size':[media[0],media[1],outer[2]]}
    s['hover_hit_area']={'center':[round(x,5),round(y,5),round(z-.010,5)],'size_m':hit}
    la=hm['label_anchor_local']; fa=hm['fullscreen_trigger_anchor_local']
    s['readable_label_anchor']={'position_m':[round(x+la[0],5),round(y+la[2],5),round(z+la[1],5)]}
    s['fullscreen_open_trigger_anchor']={'position_m':[round(x+fa[0],5),round(y+fa[2],5),round(z+fa[1],5)]}
    s['placement_state']='READY_EXACT_TEEA006_FINAL'
    s['placement_reference_batch']='TEEA_INT_20261123_006'
    s['source_visual_anchor']=src
    s['reachability_mode']=mode
    s['interaction_station_id']=station_id
    s['runtime_content_baked']=False
    s['holder_collision_runtime']='NONE_UI_HIT_ONLY'
    # Source physical geometry stays authoritative for X/Y association. The display surface Z for
    # wall media is intentionally registered just in front of TEEA006 back_decor (-1.63) so runtime
    # content is not hidden behind the baked PNG plane.
    src_measure=meas.get(key,{}).get(src)
    if src_measure:
        s['source_physical_z_extent']={'back':src_measure.get('godot_z_back'),'front':src_measure.get('godot_z_front')}
    if room in ('music','cinema'):
        s['runtime_display_plane_z']=-1.55
        s['baked_layer_reference_z']=-1.63
        s['runtime_plane_front_offset_m']=0.08
    s['placement_note']='Bound after final TEEA006 geometry; neutral holder only, runtime content remains unbaked. Wall-media runtime Z is registered in front of baked back_decor.'
    updated+=1

    rec={'surface_id':sid,'room_variant':key,'source_visual_anchor':src,'station_id':station_id,
         'position_m':s['transform']['position_m'],'holder_outer_size_m':outer,
         'room_bounds_pass':True,'unrelated_collision_overlap':[]}

    if mode=='station':
        st=station_index.get((key,station_id))
        if not st:
            errors.append(f'{sid}:missing_station:{station_id}')
        else:
            # Existing 006 station path itself is already accepted. Check the new small label footprint
            # does not overlap unrelated collidable furniture in group X/Z.
            hx=(x-outer[0]/2,x+outer[0]/2,z-outer[2]/2,z+outer[2]/2)
            for other in anchors['room_variants'][key]['stations']:
                # station records expose source collision polygon; dedupe by furniture id
                fid=other['furniture_id']
                if fid==src: continue
                poly=other.get('collision_footprint_group')
                if not poly: continue
                if overlap(hx,rb(poly)) and fid not in rec['unrelated_collision_overlap']:
                    rec['unrelated_collision_overlap'].append(fid)
            if rec['unrelated_collision_overlap']:
                errors.append(f'{sid}:holder_overlaps_unrelated:{rec["unrelated_collision_overlap"]}')
            rec['station_approach_reused_from_006']=True
            rec['station_cell_local_z']=st['cell_local_z']
    bound.append(rec)

if updated!=27:
    errors.append(f'updated_media_surface_count:{updated}:expected:27')

# Ensure no old dependency state survives in the now-finalized rooms.
for s in hooks['surfaces']:
    if s['room_id'] in ('music','cinema','artifact') and s.get('placement_state')!='READY_EXACT_TEEA006_FINAL':
        errors.append(f'{s["surface_id"]}:old_dependency_state:{s.get("placement_state")}')

hooks['schema']=2
hooks['teea006_final_binding']={
    'status':'PASS' if not errors else 'FAIL',
    'reference_batch':'TEEA_INT_20261123_006',
    'surface_count_bound':updated,
    'validation_errors':errors,
    'note':'Library surfaces remain exact TEEA005 bindings; Music/Cinema/Artifact surfaces now bind final TEEA006 geometry.'
}
P007.write_text(json.dumps(hooks,indent=2),encoding='utf-8')
(OUT/'TEEA_INT_20261123_007_media_binding_006_final.json').write_text(json.dumps({
    'schema':1,'batch_id':'TEEA_INT_20261123_007','reference_batch':'TEEA_INT_20261123_006',
    'bound_surface_count':updated,'bindings':bound,'errors':errors,'pass':not errors
},indent=2),encoding='utf-8')

# Update functional status.
fp=OUT/'TEEA_INT_20261123_007_functional_dressing_status.json'
fs=json.loads(fp.read_text())
for room in ('music','cinema','artifact'):
    fs['rooms'][room]={
        'status':'PASS' if not errors else 'FAIL',
        'reference_batch':'TEEA_INT_20261123_006',
        'evidence':[
            'final TEEA006 measured room geometry',
            'TEEA_INT_20261123_007_media_binding_006_final.json',
            'neutral holder GLBs + runtime-only content binding'
        ]
    }
fs['teea006_dependency_resolved']=not errors
fp.write_text(json.dumps(fs,indent=2),encoding='utf-8')

print(json.dumps({'updated':updated,'errors':errors,'pass':not errors},indent=2))
