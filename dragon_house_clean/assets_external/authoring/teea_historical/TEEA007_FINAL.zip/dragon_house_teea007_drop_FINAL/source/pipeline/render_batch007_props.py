import bpy,math,json
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline');P=ROOT/'batch007'/'props';PRE=P/'previews';PRE.mkdir(parents=True,exist_ok=True)
def reset():
 bpy.ops.wm.read_factory_settings(use_empty=True)
 s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=24;s.render.resolution_x=512;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG'
 try:s.view_settings.look='AgX - Medium High Contrast'
 except:pass
 w=bpy.data.worlds.new('World');s.world=w;w.use_nodes=True;w.node_tree.nodes['Background'].inputs['Color'].default_value=(.025,.025,.028,1);w.node_tree.nodes['Background'].inputs['Strength'].default_value=.18
 return s
def mat(name,c,metal=0,rough=.7,emit=None):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough
 if emit:b.inputs['Emission Color'].default_value=(*emit[0],1);b.inputs['Emission Strength'].default_value=emit[1]
 return m
def box(name,loc,size,ma):
 bpy.ops.mesh.primitive_cube_add(location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);bev=o.modifiers.new('bevel','BEVEL');bev.width=.008;bev.segments=2;return o
def setup_cam(target=(0,0,.4),loc=(.45,-.65,.45),lens=52):
 s=bpy.context.scene;cd=bpy.data.cameras.new('Cam');cam=bpy.data.objects.new('Cam',cd);s.collection.objects.link(cam);s.camera=cam;cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cd.lens=lens
 ld=bpy.data.lights.new('Key','AREA');ld.energy=650;ld.size=2.5;lo=bpy.data.objects.new('Key',ld);s.collection.objects.link(lo);lo.location=(-.8,-1.2,1.8);lo.rotation_euler=(Vector(target)-lo.location).to_track_quat('-Z','Y').to_euler()
def render(path):bpy.context.scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
# Mug previews
for stem in ['dragon_mug_lod0_empty','dragon_mug_lod0_filled','dragon_mug_lod1_empty']:
 s=reset();bpy.ops.import_scene.gltf(filepath=str(P/(stem+'.glb')));setup_cam(target=(0,0,.045),loc=(.19,-.28,.15),lens=58);render(PRE/(stem+'.png'))
# tabletop access
s=reset();bpy.ops.import_scene.gltf(filepath=str(P/'dragon_mug_lod0_filled.glb'))
table=mat('table',(0.18,.10,.06),0,.68);hand=mat('hand_env',(.12,.55,.65),0,.45)
box('TABLE',(0,0,-.035),(.70,.45,.07),table)
# hand envelope 18 x 9 x 4 cm, placed beside handle, approaching from right/front
box('QA_HAND_ENVELOPE',(.155,-.035,.055),(.18,.09,.04),hand)
setup_cam(target=(0,0,.04),loc=(.36,-.50,.28),lens=58);render(PRE/'dragon_mug_tabletop_access.png')
access={'schema':1,'asset':'DRAGON_MUG','tabletop_height_reference_m':0.75,'mug_local_placement':[0,0,0],'hand_envelope_m':[0.18,0.09,0.04],'hand_envelope_center_local_m':[0.155,-0.035,0.055],'pickup_anchor_local_m':[0,0,0.054],'approach_vector_local':[ -1,0,0 ],'status':'PASS_AUTHORING_ENVELOPE','note':'QA hand envelope is a conservative human hand access volume, not a character hand sprite.'}
(P/'mug_tabletop_access.json').write_text(json.dumps(access,indent=2))
# media holder previews
for stem in ['media_holder_book','media_holder_film_poster','media_holder_audio','media_holder_artifact','media_holder_film_screen']:
 s=reset();bpy.ops.import_scene.gltf(filepath=str(P/(stem+'.glb')))
 # determine rough object bbox
 meshes=[o for o in s.objects if o.type=='MESH'];pts=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box];mn=Vector((min(p.x for p in pts),min(p.y for p in pts),min(p.z for p in pts)));mx=Vector((max(p.x for p in pts),max(p.y for p in pts),max(p.z for p in pts)));sz=mx-mn;target=(0,0,0)
 dist=max(sz.x,sz.z)*1.5+0.4;setup_cam(target=target,loc=(dist*.25,-dist,dist*.18),lens=58);render(PRE/(stem+'.png'))
print('PREVIEWS',len(list(PRE.glob('*.png'))))

