import bpy, math, json, os
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
OUT=ROOT/'batch007'/'props'
OUT.mkdir(parents=True,exist_ok=True)

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)

def mat(name,color,metal=0.0,rough=0.6):
    m=bpy.data.materials.new(name);m.use_nodes=True
    b=m.node_tree.nodes.get('Principled BSDF')
    b.inputs['Base Color'].default_value=(*color,1)
    b.inputs['Metallic'].default_value=metal
    b.inputs['Roughness'].default_value=rough
    return m

def make_mug(lod=0,filled=False):
    reset();cer=mat('Ceramic_Oxblood',(0.18,0.025,0.035),0.0,0.34);liquid=mat('Liquid_Dark',(0.06,0.025,0.012),0.0,0.18)
    seg=32 if lod==0 else 16
    ro=.045;ri=.0385;h=.090;base=.006
    verts=[];faces=[]
    # four rings: outer bottom, outer top, inner top, inner base
    for r,z in [(ro,0),(ro,h),(ri,h),(ri,base)]:
        for i in range(seg):
            a=2*math.pi*i/seg;verts.append((r*math.cos(a),r*math.sin(a),z))
    def ring_face(a,b):
        for i in range(seg):
            j=(i+1)%seg;faces.append((a+i,a+j,b+j,b+i))
    ring_face(0,seg);ring_face(seg,2*seg);ring_face(2*seg,3*seg);ring_face(3*seg,0)
    me=bpy.data.meshes.new('MugBody');me.from_pydata(verts,[],faces);me.update()
    ob=bpy.data.objects.new('MugBody',me);bpy.context.collection.objects.link(ob);ob.data.materials.append(cer)
    # handle as closed torus loop, partially intersecting the cup wall
    bpy.ops.mesh.primitive_torus_add(
        align='WORLD',
        major_segments=(24 if lod==0 else 16),
        minor_segments=8,
        location=(.054,0,.046),
        rotation=(math.radians(90),0,0),
        major_radius=.028,
        minor_radius=.0065
    )
    hob=bpy.context.object
    hob.name='MugHandle'
    hob.data.materials.append(cer)
    # Topological union: the handle is not merely intersecting the cup wall.
    bpy.context.view_layer.objects.active=ob
    ob.select_set(True); hob.select_set(False)
    mod=ob.modifiers.new('HandleUnion','BOOLEAN')
    mod.operation='UNION'
    mod.solver='EXACT'
    mod.object=hob
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(hob,do_unlink=True)
    ob.name='MugCeramic'
    # Clean coincident vertices and recalculate normals before export.
    import bmesh
    bm=bmesh.new();bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm,verts=bm.verts,dist=1e-7)
    bmesh.ops.recalc_face_normals(bm,faces=bm.faces)
    bm.to_mesh(ob.data);bm.free();ob.data.update()
    if filled:
        bpy.ops.mesh.primitive_cylinder_add(vertices=seg,radius=ri*.96,depth=.003,location=(0,0,h-.005))
        bpy.context.object.name='Liquid';bpy.context.object.data.materials.append(liquid)
    # anchor empties
    for name,loc in [('PLACEMENT_ANCHOR',(0,0,0)),('PICKUP_ANCHOR',(0,0,h*.60)),('RIM_CENTER',(0,0,h))]:
        e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.location=loc
    return {'outer_diameter_m':ro*2,'height_m':h,'inner_diameter_m':ri*2,'base_thickness_m':base,'segments':seg}

def check_manifold_meshes():
    import bmesh
    out={}
    for o in bpy.context.scene.objects:
        if o.type=='CURVE':
            bpy.context.view_layer.objects.active=o;o.select_set(True)
            bpy.ops.object.convert(target='MESH');o.select_set(False)
    for o in bpy.context.scene.objects:
        if o.type!='MESH':continue
        bm=bmesh.new();bm.from_mesh(o.data)
        boundary=sum(1 for e in bm.edges if len(e.link_faces)!=2)
        nonman=sum(1 for e in bm.edges if not e.is_manifold)
        out[o.name]={'boundary_edges':boundary,'nonmanifold_edges':nonman,'verts':len(bm.verts),'faces':len(bm.faces)}
        bm.free()
    return out

def export_mug(lod,filled):
    meta=make_mug(lod,filled);checks=check_manifold_meshes()
    stem=f'dragon_mug_lod{lod}_{"filled" if filled else "empty"}'
    glb=OUT/(stem+'.glb')
    bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',export_materials='EXPORT')
    blend=OUT/(stem+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    return stem,glb,blend,meta,checks

report={'schema':1,'asset_family':'DRAGON_MUG','provenance':'PROJECT_ORIGINAL','variants':{}}
for lod,filled in [(0,False),(0,True),(1,False)]:
    stem,glb,blend,meta,checks=export_mug(lod,filled)
    report['variants'][stem]={'glb':str(glb),'blend':str(blend),'dimensions':meta,'mesh_qa':checks,
      'material':'Ceramic_Oxblood rough ceramic; filled state adds Liquid_Dark',
      'lod_target':'LOD0 room/tabletop close use' if lod==0 else 'LOD1 HOUSE/LEVEL distant use'}
(OUT/'mug_manifest.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))

