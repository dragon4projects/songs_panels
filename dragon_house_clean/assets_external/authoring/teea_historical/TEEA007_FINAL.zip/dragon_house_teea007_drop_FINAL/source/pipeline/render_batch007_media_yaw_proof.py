import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
L=json.loads((ROOT/'batch006'/'layout.json').read_text())
A=json.loads((ROOT/'batch006'/'generated'/'TEEA_INT_20261123_006_furniture_anchors_candidate.json').read_text())
F=json.loads((ROOT/'batch006'/'generated'/'TEEA_INT_20261123_006_foreground_layers_candidate.json').read_text())
M=json.loads((ROOT/'batch007'/'generated'/'TEEA_INT_20261123_007_media_hooks.json').read_text())
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
variant,yaw_s,out=argv[0],argv[1],argv[2]
manual_yaw=float(yaw_s)
V=L['variants'][variant]; room,var=variant.split('/'); PW=float(V['physical_width']);w=int(V['width'])
zoom=10.8+max(0,w-1)*3.1
close_bias=max(0.0,min(1.0,(48.0-zoom)/34.0))*.075
view_yaw=max(-.38,min(.38,manual_yaw+close_bias))

bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE';s.eevee.taa_render_samples=5
s.render.resolution_x=960;s.render.resolution_y=540;s.render.resolution_percentage=100;s.render.filepath=out
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.film_transparent=False
world=bpy.data.worlds.new('World');s.world=world;world.use_nodes=True
bg=world.node_tree.nodes['Background'];bg.inputs['Color'].default_value=(.018,.016,.017,1);bg.inputs['Strength'].default_value=.10

def texmat(name,path):
 img=bpy.data.images.load(str(path),check_existing=False)
 m=bpy.data.materials.new(name);m.use_nodes=True
 try:m.surface_render_method='DITHERED'
 except:pass
 nt=m.node_tree;nt.nodes.clear();outn=nt.nodes.new('ShaderNodeOutputMaterial');mix=nt.nodes.new('ShaderNodeMixShader')
 tr=nt.nodes.new('ShaderNodeBsdfTransparent');em=nt.nodes.new('ShaderNodeEmission');tx=nt.nodes.new('ShaderNodeTexImage');tx.image=img;tx.interpolation='Linear'
 nt.links.new(tx.outputs['Color'],em.inputs['Color']);em.inputs['Strength'].default_value=1
 nt.links.new(tx.outputs['Alpha'],mix.inputs[0]);nt.links.new(tr.outputs[0],mix.inputs[1]);nt.links.new(em.outputs[0],mix.inputs[2]);nt.links.new(mix.outputs[0],outn.inputs['Surface'])
 return m

def plane(name,path,gx,gy,gz,wid,hei):
 verts=[(-wid/2,0,-hei/2),(wid/2,0,-hei/2),(wid/2,0,hei/2),(-wid/2,0,hei/2)]
 mesh=bpy.data.meshes.new(name+'Mesh');mesh.from_pydata(verts,[],[(0,1,2,3)]);mesh.uv_layers.new()
 uv=mesh.uv_layers.active.data
 for li,co in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv[li].uv=co
 ob=bpy.data.objects.new(name,mesh);s.collection.objects.link(ob);ob.location=(gx,-gz,gy);ob.data.materials.append(texmat(name+'Mat',path));return ob

def emissive(name,c):
 m=bpy.data.materials.new(name);m.use_nodes=True;nt=m.node_tree;nt.nodes.clear()
 outn=nt.nodes.new('ShaderNodeOutputMaterial');em=nt.nodes.new('ShaderNodeEmission')
 em.inputs['Color'].default_value=(*c,1);em.inputs['Strength'].default_value=1.6;nt.links.new(em.outputs[0],outn.inputs['Surface']);return m

holder_mats={
 'book':emissive('book_proof',(.62,.82,.95)),
 'film':emissive('film_proof',(.95,.62,.28)),
 'audio':emissive('audio_proof',(.56,.92,.58)),
 'artifact':emissive('artifact_proof',(.92,.52,.82))
}

def import_holder(rec):
 aid=rec['holder_asset_id']; p=ROOT/'batch007'/'props'/(aid+'.glb')
 before=set(s.objects);bpy.ops.import_scene.gltf(filepath=str(p))
 new=[o for o in s.objects if o not in before]
 roots=[o for o in new if o.parent is None]
 piv=bpy.data.objects.new('PIV_'+rec['surface_id'],None);s.collection.objects.link(piv)
 for o in roots:o.parent=piv
 x,y,z=rec['transform']['position_m'];piv.location=(x,-z,y)
 # Proof material override: neutral runtime surface is bright only for inspection.
 mat=holder_mats[rec['media_kind']]
 for o in new:
  if o.type=='MESH':
   o.data.materials.clear();o.data.materials.append(mat)
 return piv

# Floor + final TEEA006 art planes.
floor_mat=emissive('floor',(.08,.055,.045))
bpy.ops.mesh.primitive_cube_add(location=(0,-.15,-.055),scale=(PW/2,1.55,.055));bpy.context.object.data.materials.append(floor_mat)
roles=[('backdrop',-1.79),('back_decor',-1.63),('furniture_back',-1.37)]
h=PW/1.5; d=ROOT/'batch006'/'final'/room/var
for rr,z in roles:plane('Art_'+rr,d/(rr+'.png'),0,1.5,z,PW,h)

# Current production perspective camera with close-bias supplement.
height_ratio=.055+(.16-.055)*max(0,min(1,(zoom-12.0)/36.0))
focus=Vector((0,0,1.45))
cam_g=Vector((math.sin(view_yaw)*zoom,1.45+zoom*height_ratio,math.cos(view_yaw)*zoom))
cam_b=Vector((cam_g.x,-cam_g.z,cam_g.y))
cd=bpy.data.cameras.new('ShelterPerspectiveCamera');cam=bpy.data.objects.new('ShelterPerspectiveCamera',cd);s.collection.objects.link(cam);s.camera=cam
cd.type='PERSP';cd.angle_y=math.radians(35)
cam.location=cam_b;cam.rotation_euler=(focus-cam.location).to_track_quat('-Z','Y').to_euler()

# Existing measured resident stations as slim neutral markers, so holder overlap is visually obvious.
actor_mat=emissive('station_marker',(.33,.45,.52))
for st in A['room_variants'][variant]['stations']:
 gx=float(st['group_local_x']);gz=float(st['cell_local_z'])
 bpy.ops.mesh.primitive_cube_add(location=(gx,-gz,.78),scale=(.10,.025,.78));bpy.context.object.data.materials.append(actor_mat)

# Exact finalized media holders for this room/variant.
recs=[r for r in M['surfaces'] if r['room_id']==room and r.get('variant')==var]
for rec in recs: import_holder(rec)

# Foreground art, if any, remains registered using TEEA006 measured physical_z.
fgs=F.get('layers',{}).get(variant,[])
if fgs:
 target_z=float(fgs[0]['physical_z'])
 reference=Vector((0,1.5,-1.37))
 den=reference.z-cam_g.z;k=(target_z-cam_g.z)/den
 fg_g=cam_g+(reference-cam_g)*k
 plane('Art_foreground',d/'foreground.png',fg_g.x,fg_g.y,target_z,PW*k,h*k)

Path(out).parent.mkdir(parents=True,exist_ok=True);bpy.ops.render.render(write_still=True)
print('MEDIA_YAW_PROOF',variant,'manual',manual_yaw,'effective',view_yaw,'holders',len(recs),out)
