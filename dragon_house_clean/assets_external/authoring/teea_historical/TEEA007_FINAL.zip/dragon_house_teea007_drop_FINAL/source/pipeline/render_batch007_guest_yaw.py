import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
L=json.loads((ROOT/'batch007'/'layout.json').read_text())
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
key,yaw_s,out=argv[0],argv[1],argv[2];yaw=float(yaw_s);R=L['rooms'][key];PW=float(R['physical_width'])
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=12;s.render.resolution_x=768;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.filepath=out;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
world=bpy.data.worlds.new('World');s.world=world;world.use_nodes=True;bg=s.world.node_tree.nodes['Background'];bg.inputs['Color'].default_value=(.025,.022,.021,1);bg.inputs['Strength'].default_value=.12

def flatmat(name,c,metal=0,rough=.8):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough;return m
def texmat(name,path):
 img=bpy.data.images.load(str(path),check_existing=False);m=bpy.data.materials.new(name);m.use_nodes=True
 try:m.surface_render_method='DITHERED'
 except:pass
 nt=m.node_tree;nt.nodes.clear();outn=nt.nodes.new('ShaderNodeOutputMaterial');mix=nt.nodes.new('ShaderNodeMixShader');tr=nt.nodes.new('ShaderNodeBsdfTransparent');em=nt.nodes.new('ShaderNodeEmission');tx=nt.nodes.new('ShaderNodeTexImage');tx.image=img
 nt.links.new(tx.outputs['Color'],em.inputs['Color']);em.inputs['Strength'].default_value=1;nt.links.new(tx.outputs['Alpha'],mix.inputs[0]);nt.links.new(tr.outputs[0],mix.inputs[1]);nt.links.new(em.outputs[0],mix.inputs[2]);nt.links.new(mix.outputs[0],outn.inputs['Surface']);return m
def plane(name,path,gx,gy,gz,w,h):
 verts=[(-w/2,0,-h/2),(w/2,0,-h/2),(w/2,0,h/2),(-w/2,0,h/2)];me=bpy.data.meshes.new(name+'Mesh');me.from_pydata(verts,[],[(0,1,2,3)]);me.uv_layers.new()
 for li,co in enumerate([(0,0),(1,0),(1,1),(0,1)]):me.uv_layers.active.data[li].uv=co
 o=bpy.data.objects.new(name,me);s.collection.objects.link(o);o.location=(gx,-gz,gy);o.data.materials.append(texmat(name+'Mat',path));return o
def cube(name,gx,gy,gz,sx,sy,sz,ma):
 # Godot xyz -> Blender x,-z,y
 bpy.ops.mesh.primitive_cube_add(location=(gx,-gz,gy));o=bpy.context.object;o.name=name;o.dimensions=(sx,sz,sy);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);return o

room,var=key.split('/');d=ROOT/'batch007'/'final'/room/var
h=PW/1.5
for role,z in [('backdrop',-1.79),('back_decor',-1.63),('furniture_back',-1.37)]:plane('Art_'+role,d/(role+'.png'),0,1.5,z,PW,h)
floor=flatmat('floor',(.11,.075,.06));cube('QA_Floor',0,-.055,-.05,PW,.11,2.9,floor)

zoom=10.8
close_bias=max(0.0,min(1.0,(48.0-zoom)/34.0))*0.075
view_yaw=max(-0.38,min(0.38,yaw+close_bias))
height_ratio=.055+(.16-.055)*max(0.0,min(1.0,(zoom-12.0)/36.0))
cam_g=Vector((math.sin(view_yaw)*zoom,1.45+zoom*height_ratio,math.cos(view_yaw)*zoom))
focus=Vector((0,0,1.45));cam_b=Vector((cam_g.x,-cam_g.z,cam_g.y))
cd=bpy.data.cameras.new('RoomCamera');cam=bpy.data.objects.new('RoomCamera',cd);s.collection.objects.link(cam);s.camera=cam;cd.type='PERSP';cd.angle=math.radians(35);cam.location=cam_b;cam.rotation_euler=(focus-cam.location).to_track_quat('-Z','Y').to_euler()

cyan=flatmat('clearance',(0.05,.58,.68),0,.42);gold=flatmat('hook',(.78,.43,.08),0,.5)
# Conservative QA envelope from current runtime contract:
# verified non-Manjka actors use pixel_size = 1.9 / texture_height.
# Guest banks are 512x512, so the full visible plane is at most 1.9 x 1.9 m.
cube('MAX_RUNTIME_SPRITE_PLANE',0,0.95,.25,1.90,1.90,.16,cyan)
if key=='guest_centaur/R1':
    # 2.50 m turning envelope on the room floor; this is room-clearance QA, not anatomy.
    bpy.ops.mesh.primitive_torus_add(major_radius=1.25,minor_radius=.028,major_segments=64,minor_segments=8,location=(0,-.25,.035))
    bpy.context.object.name='CENTAUR_TURNING_ENVELOPE'
    bpy.context.object.data.materials.append(gold)
elif key=='guest_miu/R1':
    # Form-neutral interaction hooks only; no humanoid/quadruped body is asserted.
    for i,(x,z) in enumerate([(-1.35,-1.18),(.55,-.25),(1.55,-1.12),(.15,-1.10)]):
      cube('FORM_CONDITIONAL_HOOK_'+str(i),x,.12,z,.18,.24,.18,gold)

# QA light for non-emissive clearance placeholders/floor only; production PNG planes are emissive.
ld=bpy.data.lights.new('QA_Key','AREA');ld.energy=850;ld.shape='DISK';ld.size=4.0
lo=bpy.data.objects.new('QA_Key',ld);s.collection.objects.link(lo);lo.location=(0,-4.0,4.0);lo.rotation_euler=(Vector((0,0,1.0))-lo.location).to_track_quat('-Z','Y').to_euler()
Path(out).parent.mkdir(parents=True,exist_ok=True);bpy.ops.render.render(write_still=True);print('YAW',key,'manual',yaw,'effective',view_yaw,'zoom',zoom,out)

