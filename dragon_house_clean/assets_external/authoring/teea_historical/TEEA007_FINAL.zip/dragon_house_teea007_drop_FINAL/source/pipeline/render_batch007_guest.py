import bpy,sys,json,math,os
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline')
L=json.loads((ROOT/'batch007'/'layout.json').read_text())
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
key,role,out,rx,ry=argv[0],argv[1],argv[2],int(argv[3]),int(argv[4])
R=L['rooms'][key];PW=float(R['physical_width'])
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=int(os.environ.get('DH_SAMPLES','12'))
s.render.resolution_x=rx;s.render.resolution_y=ry;s.render.resolution_percentage=100;s.render.filepath=out
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='8';s.render.image_settings.compression=35;s.render.film_transparent=True
try:s.view_settings.look='AgX - Medium High Contrast'
except:pass

def append_mat(path):
 with bpy.data.libraries.load(str(path),link=False) as (src,dst):dst.materials=[src.materials[0]]
 return dst.materials[0]
rock=append_mat(ROOT/'materials/Rock035/Rock035_1K-JPG.blend');wood=append_mat(ROOT/'materials/Wood051/Wood051_1K-JPG.blend')
def flatmat(name,c,metal=0,rough=.8,emit=None):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough
 if emit:b.inputs['Emission Color'].default_value=(*emit[0],1);b.inputs['Emission Strength'].default_value=emit[1]
 return m
dark=flatmat('dark',(.01,.008,.007),0,.95);plaque=flatmat('plaque',(.10,.055,.038),0,.72);textmat=flatmat('text',(0.72,.52,.32),.05,.45,((.20,.07,.03),.35));rug=flatmat('rug',(.16,.055,.045),0,.92)
def box(name,loc,size,ma,bevel=.018):
 bpy.ops.mesh.primitive_cube_add(location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  md=o.modifiers.new('edge','BEVEL');md.width=bevel;md.segments=2
 o.data.materials.append(ma);return o
def bbox(objs):
 pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box]
 return Vector((min(p.x for p in pts),min(p.y for p in pts),min(p.z for p in pts))),Vector((max(p.x for p in pts),max(p.y for p in pts),max(p.z for p in pts)))
def source_gltf(aid):
 d=json.loads(next((ROOT/'source_assets'/aid).glob('*/SOURCE.json')).read_text())
 return Path(d.get('gltf_normalized') or d['gltf'])
def import_asset(o):
 gp=source_gltf(o['asset']);before=set(s.objects);bpy.ops.import_scene.gltf(filepath=str(gp))
 new=[x for x in s.objects if x not in before];meshes=[x for x in new if x.type=='MESH'];roots=[x for x in new if x.parent is None]
 piv=bpy.data.objects.new('PIV_'+o['id'],None);s.collection.objects.link(piv)
 for x in roots:x.parent=piv
 sc=float(o.get('scale',1));piv.scale=(sc,sc,sc);piv.rotation_euler[2]=math.radians(float(o.get('rot',0)))
 bpy.context.view_layer.update();mn,mx=bbox(meshes)
 piv.location.x+=-(mn.x+mx.x)/2+float(o['x']);piv.location.y+=-(mn.y+mx.y)/2+(-float(o['z']));piv.location.z+=-mn.z+float(o.get('height',0))
 bpy.context.view_layer.update();return piv
def rear_shell():
 n=9;seg=PW/n
 for i in range(n):
  x=-PW/2+seg*(i+.5);h=2.90+[.04,-.02,.07,-.05,.02][i%5]
  box('rock'+str(i),(x,2.04,h/2),(seg+.035,.28,h),rock,.055)
 box('base',(0,1.84,.13),(PW-.20,.14,.15),wood,.014);box('head',(0,1.86,2.90),(PW-.16,.16,.13),wood,.014)
 for x in [-PW/2+.10,PW/2-.10]:box('edge',(x,1.86,1.50),(.16,.16,2.75),wood,.014)
 # Guest-room access recess sized from the measured authoring contract.
 dw=float(R['sizing_contract'].get('door_clear_width_m',.95))
 dh=float(R['sizing_contract'].get('door_clear_height_m',2.20))
 dcx=1.25
 box('door_recess',(dcx,1.88,dh/2),(dw,.055,dh),dark,.025)
def make_text_label(p):
 x=float(p['x']);y=-float(p['z']);w=float(p['width']);h=float(p['height'])
 box(p['id']+'_plaque',(x,y,2.45),(w,.055,h),plaque,.022)
 font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
 cu=bpy.ops.object.text_add(location=(x,y-.034,2.45-h*.09),rotation=(math.radians(90),0,0))
 o=bpy.context.object;o.name=p['id']+'_text';o.data.body=p['text'];o.data.align_x='CENTER';o.data.align_y='CENTER';o.data.size=.19;o.data.extrude=.006;o.data.bevel_depth=.0015
 try:o.data.font=bpy.data.fonts.load(font)
 except:pass
 o.data.materials.append(textmat)
 # text object lies in XY after rotation tweak; orient toward camera (-Y)
 o.rotation_euler=(math.radians(90),0,0)
def rest_platform(p):
 box(p['id'],(float(p['x']),-float(p['z']),float(p['height'])/2),(float(p['width']),float(p['depth']),float(p['height'])),rug,.035)
 # soft top roll, low and non-chair-like
 box(p['id']+'_top',(float(p['x']),-float(p['z']),float(p['height'])+.035),(float(p['width'])*.92,float(p['depth'])*.82,.07),rug,.035)
def proc(p):
 if p['type']=='label':make_text_label(p)
 elif p['type']=='rest_platform':rest_platform(p)
if role=='backdrop':rear_shell()
elif role=='back_decor':
 for o in R.get('objects',[]):
  if o['role']=='back_decor':import_asset(o)
 for p in R.get('procedural',[]):
  if p['role']=='back_decor':proc(p)
elif role=='furniture_back':
 for o in R.get('objects',[]):
  if o['role']=='furniture_back':import_asset(o)
 for p in R.get('procedural',[]):
  if p['role']=='furniture_back':proc(p)
else:raise RuntimeError(role)

# camera same width-authoring contract
cd=bpy.data.cameras.new('WIDTH_CAMERA');cam=bpy.data.objects.new('WIDTH_CAMERA',cd);s.collection.objects.link(cam);s.camera=cam
cam.location=(0,-12,1.5);cam.rotation_euler=(Vector((0,0,1.5))-cam.location).to_track_quat('-Z','Y').to_euler();cd.type='ORTHO';cd.ortho_scale=PW
world=bpy.data.worlds.new('World');s.world=world;world.use_nodes=True;bg=s.world.node_tree.nodes['Background'];bg.inputs['Color'].default_value=(.02,.017,.016,1);bg.inputs['Strength'].default_value=.16
# slightly different practical tone by guest, without personality lore
if key.startswith('guest_centaur'): color=(1.0,.72,.48);energy=300
elif key.startswith('guest_vampire'): color=(.92,.78,.66);energy=260
else: color=(1.0,.68,.46);energy=250
ld=bpy.data.lights.new('Area','AREA');ld.energy=energy;ld.size=3.2;ld.color=color;lo=bpy.data.objects.new('Area',ld);s.collection.objects.link(lo);lo.location=(0,-2.8,2.45);lo.rotation_euler=(Vector((0,.5,1.2))-lo.location).to_track_quat('-Z','Y').to_euler()
Path(out).parent.mkdir(parents=True,exist_ok=True);bpy.ops.render.render(write_still=True);print('RENDERED',key,role,out)

