import bpy,bmesh,json
from pathlib import Path
from mathutils import Vector
ROOT=Path('/home/user/dragonhouse_asset_pipeline');P=ROOT/'batch007/props';OUT=ROOT/'batch007/generated';OUT.mkdir(parents=True,exist_ok=True)
files=['dragon_mug_lod0_empty.glb','dragon_mug_lod0_filled.glb','dragon_mug_lod1_empty.glb','media_holder_book.glb','media_holder_film_poster.glb','media_holder_audio.glb','media_holder_artifact.glb','media_holder_film_screen.glb','dragon_fur_rest_mat.glb']
req_holder={'MEDIA_SURFACE','LABEL_ANCHOR','HOVER_HIT','FULLSCREEN_TRIGGER_ANCHOR','PLACEMENT_ANCHOR'}
rep={'schema':1,'batch_id':'TEEA_INT_20261123_007','files':{},'errors':[]}
for fn in files:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 p=P/fn
 try:
  bpy.ops.import_scene.gltf(filepath=str(p))
  names={o.name for o in bpy.context.scene.objects};meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
  pts=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box]
  mn=Vector((min(q.x for q in pts),min(q.y for q in pts),min(q.z for q in pts)));mx=Vector((max(q.x for q in pts),max(q.y for q in pts),max(q.z for q in pts)))
  mr={}
  for o in meshes:
   bm=bmesh.new();bm.from_mesh(o.data)
   # glTF may split coincident vertices for normals/UV seams; weld geometric duplicates
   # before testing watertightness of the imported surface.
   bmesh.ops.remove_doubles(bm,verts=bm.verts,dist=1e-7)
   boundary=sum(1 for e in bm.edges if len(e.link_faces)!=2)
   nonman=sum(1 for e in bm.edges if not e.is_manifold)
   mr[o.name]={'verts':len(bm.verts),'faces':len(bm.faces),'boundary_edges':boundary,'nonmanifold_edges':nonman}
   bm.free()
   if fn.startswith('dragon_mug') and o.name!='Liquid' and (boundary or nonman):
    rep['errors'].append(f'{fn}:{o.name}:nonmanifold')
  if fn.startswith('media_holder'):
   missing=sorted(req_holder-names)
   if missing:rep['errors'].append(f'{fn}:missing_nodes:{missing}')
  rep['files'][fn]={'exists':p.exists(),'bytes':p.stat().st_size,'bbox_m':[float(x) for x in (mx-mn)],'nodes':sorted(names),'mesh_qa':mr}
 except Exception as e:
  rep['errors'].append(fn+':'+str(e))
rep['pass']=not rep['errors']
(OUT/'TEEA_INT_20261123_007_prop_mesh_qa.json').write_text(json.dumps(rep,indent=2))
print(json.dumps({'pass':rep['pass'],'errors':rep['errors'],'files':{k:{'bbox_m':v['bbox_m'],'nodes':[n for n in v['nodes'] if n in req_holder]} for k,v in rep['files'].items()}},indent=2))

